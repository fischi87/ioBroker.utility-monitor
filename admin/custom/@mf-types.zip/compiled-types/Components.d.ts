declare const components: Record<string, any>;
export default components;
